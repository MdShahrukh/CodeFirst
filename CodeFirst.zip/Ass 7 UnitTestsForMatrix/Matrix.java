
package matrixtest;


public class Matrix implements iMatrix {
    int sumOfEvenIndexElements = 0;
    int sumOfOddIndexElements = 0;
    @Override
    public Integer[][] getInputMatrixFromUser() {
        throw new UnsupportedOperationException("Not implemented yet"); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void displayResults() {
        throw new UnsupportedOperationException("Not implemented yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void calculateSumOfAlternateIndexElements(Integer[][] inputMatrix) {
        throw new UnsupportedOperationException("Not implemented yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void getDataAtSpecificLocation(int rowIndex, int colIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    
}