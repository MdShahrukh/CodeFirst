#include <iostream>
using namespace std;
int validateTestcases();
int validatePlayerId(int playerId);
int validatePass();
int main() 
{	
	int testCase,i=0;
	
    	//Enter number of test cases.
	//cin>>testCase;
	//if(!validateTestcases(cin>>testCase;))
	//	return 0;
	testCase=validateTestcases();
	int cases=testCase;
	int arr[testCase];

    	while(cases--) 
		{
   	 	int passes,player_id, last_id;
		 //Enter no of passes and first player Id
    		cin>>passes;
		cin>>player_id;
		
    		last_id=player_id;

    		while(passes--)
			{
        		
				char action;
				char pass='P', back_pass='B';
	      		cin>>action; 

               		if(action == pass)
					{
						int id;
            			cin>>id;
            			last_id = player_id;
            			player_id = id;
					}
        		else   //backpass
					 {	//Swapping the player Id's
               			player_id = last_id + player_id;
               			  last_id = player_id - last_id;
               			player_id = player_id - last_id;
					}
			}
   		 	//Collecting the outputs into single array to display them together.
    		arr[i++]=player_id;
    	}
		//Displaying the outputs.
    	for(int k=0;k<testCase;k++)
    	{ cout<<"Player "<<arr[k]<<endl;
		}
    	return 0;
}

int validateTestcases()
	{	int testcases;
		while(cin>>testcases<0)
			printf("Enter valid no of testcases range b/w 0 to 100");
		/*cin>>testcases;
		if(testcases>0&&testcases<=100)
			return 1;
		else 
		{
			printf("Enter valid no of testcases range b/w 0 to 100");
			return 0;
		}*/
	}
	
validatePlayerId(int playerId)
	{ 
		if(playerId>0&&playerId<=100000)
		return 1;
		else
		{
			printf("Enter a valid player Id ranging from 0 to 100000");
			return 0;
		}
	
	}
validatePass(char typeOfPass)
	{
		if(typeOfPass=='P'||typeOfPass=='p'||typeOfPass=='B'||typeOfPass=='b')
			return 1;
		else
			{
			printf("Enter a valid Pass Either P or B");
			return 0;
			}
	}
