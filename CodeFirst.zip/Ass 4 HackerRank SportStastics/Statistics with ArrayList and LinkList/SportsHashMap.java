/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sportspopularitysurveywithdatastructure;

/**
 *
 * @author mohammad.shahrukh
 */
public class SportsHashMap {
      String sportsName;
	int sportsPopulirity;
	public String getSportsName() {
		return sportsName;
	}
	public void setSportsName(String sportsName) {
		this.sportsName = sportsName;
	}
	public int getSportsPopulirity() {
		return sportsPopulirity;
	}
	public void setSportsPopulirity(int sportsPopulirity) {
		this.sportsPopulirity = sportsPopulirity;
	}
}
