/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashmap;

import java.util.Scanner;

/**
 *
 * @author mohammad.shahrukh
 */
public class CustomHashMap {
     static Scanner sc = new Scanner(System.in);
     
     
    public static void main(String[] args) {
        HashMap<String, String> customHashMap = new HashMap<String,String>();
        customHashMap.put("SRK", "Shahrukh");
        customHashMap.put("yash", "YashWnat");
        System.out.println(customHashMap.get("SRK"));
        System.out.println(customHashMap.get("yash"));
        customHashMap.printHashMap();
    }
}
